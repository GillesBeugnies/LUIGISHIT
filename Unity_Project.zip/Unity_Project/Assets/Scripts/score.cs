using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class ScoreManager : MonoBehaviour
{
    public TMP_Text ScoreText; 
    private int currentScore;

    void Start()
    {
        currentScore = 0;
        ScoreText.text = "Score: " + currentScore.ToString();
    
    }

    public void UpdateScore(int pointsToAdd)
    {
        currentScore += pointsToAdd;
        ScoreText.text = "Score: " + currentScore.ToString();
    }
}
