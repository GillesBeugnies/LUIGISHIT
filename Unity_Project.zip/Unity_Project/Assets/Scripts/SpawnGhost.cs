using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn : MonoBehaviour
{
    [SerializeField] private GameObject _ghostPrefab;
    [SerializeField] private float _minSpawnTime = 2f; 
    [SerializeField] private float _maxSpawnTime = 5f; 
    private float nextSpawnTime;

    private void Start()
    {
        nextSpawnTime = Time.time + Random.Range(_minSpawnTime, _maxSpawnTime); 

    }

    // Update is called once per frame
    private void Update()
    {
        if (Time.time >= nextSpawnTime) 
        {
            Instantiate(_ghostPrefab, transform.position, transform.rotation); 
            nextSpawnTime = Time.time + Random.Range(_minSpawnTime, _maxSpawnTime); 
        }
    }
}
