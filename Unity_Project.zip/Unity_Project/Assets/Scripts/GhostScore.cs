using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class Ghostscore : MonoBehaviour
{
    public TMP_Text ScoreText; 
    private int _currentScore;

    void Start()
    {
        _currentScore = 0;
        ScoreText.text = _currentScore.ToString();

    }

    public void UpdateScore(int pointsToAdd)
    {
        _currentScore = pointsToAdd;
        ScoreText.text = _currentScore.ToString();
    }
}
