using UnityEngine;

public class Character : MonoBehaviour
{
    [SerializeField] private CharacterController _characterController;
    [SerializeField] private float _speed = 5f;
    [SerializeField] private Transform _cameraTransform;
    public float SmootThurn = 0.1f;
    float SmoothturnVelocity;
    public float CaptureRadius = 1.0f;

    private Transform _capturedGhost;
    private Ghost _ghostScript;
   

    // Update is called once per frame
    void Update()
    {
        float horizontalInput = Input.GetAxis("Horizontal");
        float verticalInput = Input.GetAxis("Vertical");

        Vector3 forward = _cameraTransform.forward;
        Vector3 right = _cameraTransform.right;
        forward.y = 0f;
        right.y = 0f;
        forward.Normalize();
        right.Normalize();

        Vector3 movementDirection = forward * verticalInput + right * horizontalInput;
        movementDirection.Normalize();

        _characterController.Move(movementDirection * _speed * Time.deltaTime);

        
        if (Input.GetMouseButtonDown(0))
        {
            Collider[] hitColliders = Physics.OverlapSphere(transform.position, CaptureRadius);
            foreach (Collider collider in hitColliders)
            {
                if (collider.CompareTag("Ghost"))
                {

                    Ghost _ghostScript = collider.GetComponent<Ghost>();
                    if (_ghostScript != null)
                    {
                        _ghostScript.StartCountdown();   
                    }
                    else
                    {
                      
                        Debug.Log("No Ghost script found on collided object!");

                    }

                    _capturedGhost = collider.transform;
                    _capturedGhost.parent = transform;
                    _capturedGhost.localPosition = Vector3.right * 3f; 
                }

            }
        }
        if (Input.GetMouseButtonUp(0) && _capturedGhost != null)
        {
            Debug.Log("ghost stopped");
            _capturedGhost?.GetComponent<Ghost>()?.StopCountdown();
            _capturedGhost.parent = null;
            _capturedGhost = null;
            _ghostScript = null; 
        }

        if (_capturedGhost != null)
{
    float distance = Vector3.Distance(transform.position, _capturedGhost.position);

    if (distance > 5f)
    {
        Debug.Log("Ghost escaped!");
        _capturedGhost.GetComponent<Ghost>().StopCountdown();
        _capturedGhost.parent = null;
        _capturedGhost = null;
        _ghostScript = null;
    }
}
    }
}
