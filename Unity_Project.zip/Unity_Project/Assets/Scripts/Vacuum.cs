    using UnityEngine;

public class StickRotation : MonoBehaviour
{
    public float sensitivity = 1.0f;
    public float minZRotation = 70f;
    public float maxZRotation = 130f;

    void Start()
    {
        transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
    }

    private void Update()
    {
        float mouseX = Input.GetAxis("Mouse Y");
        float deltaY = mouseX * sensitivity;

        Vector3 currentRotation = transform.localRotation.eulerAngles;

        float newRotationZ = currentRotation.z + deltaY;

        newRotationZ = Mathf.Clamp(newRotationZ, minZRotation, maxZRotation);

        transform.localRotation = Quaternion.Euler(currentRotation.x, currentRotation.y, newRotationZ);
    }
}
