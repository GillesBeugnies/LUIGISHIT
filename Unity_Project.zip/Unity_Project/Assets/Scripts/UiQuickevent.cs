using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UiQuickevent : MonoBehaviour
{

    public Image fButton;

    // Start is called before the first frame update
    void Start()
    {
        fButton.enabled = false;

    }

    // Update is called once per frame
    public void EnableButton()
    {
        fButton.enabled = true;
    }

    public void DisableButton()
    {
        fButton.enabled = false;
    }
}

