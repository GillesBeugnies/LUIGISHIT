using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro; 
using UnityEngine.SceneManagement;

public class SpawnCoins : MonoBehaviour
{
    public GameObject CoinPrefab;
    public float MinSpawnTime = 1f;
    public float MaxSpawnTime = 20f;
    private ScoreManager _scoreManager;
    private int _activeCoins = 0;

    void Start()
    {
        GameObject canvas = GameObject.Find("Canvas"); 
        if (canvas != null)
        {
            TextMeshProUGUI textMeshPro = canvas.GetComponentInChildren<TextMeshProUGUI>();
            if (textMeshPro != null)
            {
                _scoreManager = textMeshPro.GetComponent<ScoreManager>();
            }
        }

        if (_scoreManager == null)
        {
            Debug.LogError("ScoreManager not found!");
            return;
        }

        StartSpawningCoins();
    }

    void StartSpawningCoins()
    {
        if (_activeCoins < 5) 
        {
            float spawnTime = Random.Range(MinSpawnTime, MaxSpawnTime);
            Invoke("SpawnCoin", spawnTime);
        }
    }

    void SpawnCoin()
    {
        Vector3 spawnPosition = new Vector3(Random.Range(-5f, 5f), 0.5f, Random.Range(-5f, 5f));
        Quaternion spawnRotation = Quaternion.Euler(0f, 0f, 90f);
        Instantiate(CoinPrefab, spawnPosition, spawnRotation);
        _activeCoins++;
        Debug.Log("Coin Spawned");
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            Debug.Log("Coin collected");

            if (_scoreManager != null)
            {
                _scoreManager.UpdateScore(1);
            }
            else
            {
                Debug.LogError("ScoreManager is not assigned!");
            }

            Destroy(gameObject);
            _activeCoins--; 
        }
    }
}
