using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class SpawnPowerups : MonoBehaviour
{
    public GameObject powerupPrefab; 
    public float MinSpawnTime = 1f;
    public float MaxSpawnTime = 20f;
    private ScoreManager ScoreManager;

    private int _activePowerups = 0; 

    void Start()
    {
        GameObject canvas = GameObject.Find("Canvas"); 
        if (canvas != null)
        {
            TextMeshProUGUI textMeshPro = canvas.GetComponentInChildren<TextMeshProUGUI>();
            if (textMeshPro != null)
            {
                ScoreManager = textMeshPro.GetComponent<ScoreManager>();
            }
        }

        if (ScoreManager == null)
        {
            Debug.LogError("ScoreManager not found!");
            return;
        }

        StartSpawningPowerups();
    }

    void StartSpawningPowerups()
    {
        if (_activePowerups < 2)
        {
            float spawnTime = Random.Range(MinSpawnTime, MaxSpawnTime);
            Invoke("SpawnPowerup", spawnTime);
        }
    }

    void SpawnPowerup()
    {
        Vector3 spawnPosition = new Vector3(Random.Range(-5f, 5f), 0.5f, Random.Range(-5f, 5f));
        Quaternion spawnRotation = Quaternion.Euler(0f, 0f, 90f);
        Instantiate(powerupPrefab, spawnPosition, spawnRotation);
        _activePowerups++;
        Debug.Log("Powerup Spawned");
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            Debug.Log("Powerup collected");
            if (ScoreManager != null)
            {
                ScoreManager.UpdateScore(5);
            }
            else
            {
                Debug.LogError("ScoreManager is not assigned!");
            }
            Destroy(gameObject);
            _activePowerups--; 
        }
    }
}
