using UnityEngine;

public class Camera : MonoBehaviour
{
    public float Sensitivity = 1.0f;
    public float MinXRotation = 0.0f;
    public float MaxXRotation = 15.0f;
    public Transform player;
    private void Update()
    {
        Vector3 desiredPosition = player.position + new Vector3(0.5f, 2f, -4f); 

        transform.position = Vector3.Lerp(transform.position, desiredPosition, Time.deltaTime * 5f);
        float mouseY = Input.GetAxis("Mouse Y");
        float deltaX = mouseY * Sensitivity;
        Vector3 currentRotation = transform.localRotation.eulerAngles;
        float newRotationX = currentRotation.x - deltaX;
        newRotationX = Mathf.Clamp(newRotationX,MinXRotation,MaxXRotation);
        transform.localRotation = Quaternion.Euler(newRotationX,currentRotation.y,currentRotation.z);



    }
}
