using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Timer : MonoBehaviour
{

    public TMP_Text ClockTimer;
    private float _currentTime;
    private float _startingTime = 180f;
    void Start()
    {
        _currentTime = _startingTime;
        StartCoroutine(Countdown());
    }

    IEnumerator Countdown()
    {
        while (_currentTime > 0)
        {
            _currentTime -= Time.deltaTime;
            UpdateTimerDisplay();
            yield return null;
        }

        EndGame();
    }

    void UpdateTimerDisplay()
    {
        int minutes = Mathf.FloorToInt(_currentTime / 60);
        int seconds = Mathf.FloorToInt(_currentTime % 60);

        ClockTimer.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }

    void EndGame()
    {
        Debug.Log("Time's up! Game Over.");
        SceneManager.LoadScene("Menu");
    }
}