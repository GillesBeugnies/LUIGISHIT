using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;

public class Ghost : MonoBehaviour
{
    public int CountdownDuration = 15;
    private int CountdownTimer;
    private bool _isCountingDown = false;
    public float Speed = 0.5f;
    public Transform Player;
    public Transform Vacuum;
    private ScoreManager _scoreManager;
    private UiQuickevent _uiQuickevent;
    public float FastDecreaseRate = 5.0f;

    private float _timeSinceCloseToVacuum = 0.0f;
    private Vector3 _targetPosition;
    private float _minHeight = 1f;
    private float _maxHeight = 4f;
    public Image FButton;



    void Start()
    {
        _targetPosition = GetRandomTargetPosition();
        GameObject canvas = GameObject.Find("Canvas");
        if (canvas != null)
        {
            _uiQuickevent = FButton.GetComponent<UiQuickevent>();
            TextMeshProUGUI textMeshPro = canvas.GetComponentInChildren<TextMeshProUGUI>();
            if (textMeshPro != null)
            {
                _scoreManager = textMeshPro.GetComponent<ScoreManager>();
            }
        }


        if (_scoreManager == null)
        {
            Debug.LogError("ScoreManager not found!");
            return;
        }
     

        if (_uiQuickevent == null)
        {
            Debug.LogError("UIQUICKNOT FOUNd");
        }
        Vacuum = GameObject.FindGameObjectWithTag("Vacuum").transform;
        Player = GameObject.FindGameObjectWithTag("Player").transform;

        if (Vacuum == null || Player == null)
        {
            Debug.LogError("Vacuum or Player not found! Please ensure they have the appropriate tags.");
        }


        CountdownTimer = CountdownDuration;
    }

    // Update is called once per frame
    void Update()
    {
        _targetPosition.y = Mathf.Clamp(_targetPosition.y, _minHeight, _maxHeight);

        
        Vector3 directionToTarget = (_targetPosition - transform.position).normalized;
        Vector3 movement = directionToTarget * Speed * Time.deltaTime;

        // Avoid the wall
        if (Physics.Raycast(transform.position, directionToTarget, out RaycastHit hit, 0.6f))
        {
            if (hit.collider.CompareTag("Wall"))
            {
                
                movement += hit.normal * Speed * Time.deltaTime;
            }
        }

        transform.position += movement;

        if (Vector3.Distance(transform.position, _targetPosition) < 0.5f)
        {
            if (!_isCountingDown)
            {
                _targetPosition = GetRandomTargetPosition();
            }

        }
        if (_isCountingDown)
        {
            float distanceToVacuum = Vector3.Distance(transform.position, Vacuum.position);

            Vector3 directionToPlayer = (Player.transform.position - transform.position).normalized;
            Vector3 directionToVacuum = (Vacuum.position - transform.position).normalized;
            Vector3 directionAwayFromPlayer = -directionToPlayer.normalized; 

            
            Vector3 combinedDirection;

            if (distanceToVacuum < 4f)
            {

                _timeSinceCloseToVacuum += Time.deltaTime;

                if (_timeSinceCloseToVacuum >= 3.0f)
                {
                    _uiQuickevent.EnableButton();
                    if (Input.GetKeyDown(KeyCode.F))
                    {
                        Debug.Log("Button F is pressed");
                        CountdownTimer -= 5;
                        _timeSinceCloseToVacuum = 0.0f; 
                        _uiQuickevent.DisableButton();
                    }
                }

                if (_timeSinceCloseToVacuum >= 6.0f) 
                {
                    Debug.Log("Ghost Escaped!");
                    StopCountdown();
                    combinedDirection = directionAwayFromPlayer;
                }
                else
                {
                    // Move towards vacuum
                    combinedDirection = directionToVacuum;
                }
            }
            else
            {
                combinedDirection = (_targetPosition - transform.position).normalized;
                _timeSinceCloseToVacuum = 0.0f;
            }

            transform.position += combinedDirection * Speed * Time.deltaTime;
        }
    }


    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Wall"))
        {
            _targetPosition = GetRandomTargetPosition();

            Vector3 directionAwayFromWall = (transform.position - collision.contacts[0].point).normalized;

            transform.position += directionAwayFromWall * Speed * Time.deltaTime;
        }
    }

    public void StartCountdown()
    {
        _isCountingDown = true;
        InvokeRepeating(nameof(Countdown), 1f, 1f);
    }

    public void StopCountdown()
    {
        Debug.Log("Countdown Has stopped");
        _isCountingDown = false;
        CancelInvoke(nameof(Countdown));
    }

    private void Countdown()
    {
        CountdownTimer--;
        Debug.Log(CountdownTimer);
        if (CountdownTimer <= 0)
        {
            Dissappear();
        }
    }

    private void Dissappear()
    {


        gameObject.SetActive(false);
        _scoreManager.UpdateScore(1);
        CancelInvoke(nameof(Countdown));
    }

    bool IsCloseToVacuum()
    {
        float treshold = 1.2f;
        float distanceToVacuum = Vector3.Distance(transform.position, Vacuum.position);
        return distanceToVacuum <= treshold;
    }
    private Vector3 GetRandomTargetPosition()
  {
    Vector3 randomOffset = Random.insideUnitSphere * 5f; 
    randomOffset.y = 0f; 

    float biasChance = 0.7f; 
    if (Random.value < biasChance)
    {
      randomOffset.x += 2f;
    }

    return transform.position + randomOffset;
  }
}